package com.adlo.business

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF16A34A)
private val Ink = Color(0xFF0F172A)
private val Muted = Color(0xFF64748B)
private val moneyFmt = NumberFormat.getCurrencyInstance(Locale("es", "HN")).apply { maximumFractionDigits = 2 }
private fun money(v: Double) = moneyFmt.format(v)
private fun stamp() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
private fun dayStamp() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

data class Product(val id: Long, val name: String, val price: Double, val desc: String)
data class Line(val productId: Long, val name: String, val price: Double, val qty: Int) { val total get() = price * qty }
data class Sale(val id: Long, val client: String, val date: String, val lines: List<Line>, val total: Double)
data class Draft(val id: Long, val client: String, val date: String, val lines: List<Line>, val total: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ADLOApp(this) }
    }
}

@Composable
fun ADLOApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("adlo_native_v1", Context.MODE_PRIVATE) }
    fun readProducts(): MutableList<Product> {
        val raw = prefs.getString("products", null) ?: return mutableListOf(
            Product(1, "Café Expresso", 2.50, "Café caliente 8oz"),
            Product(2, "Empanada de Queso", 1.75, "Empanada artesanal"),
            Product(3, "Jugo Natural 500ml", 3.00, "Naranja o fresa"),
            Product(4, "Sandwich Jamón y Queso", 4.50, "Pan integral tostado")
        )
        return runCatching {
            val a = JSONArray(raw)
            MutableList(a.length()) { i -> a.getJSONObject(i).let { Product(it.getLong("id"), it.getString("name"), it.getDouble("price"), it.optString("desc")) } }
        }.getOrDefault(mutableListOf())
    }
    fun writeProducts(list: List<Product>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("price", it.price).put("desc", it.desc)) }
        prefs.edit().putString("products", a.toString()).apply()
    }
    fun readLines(json: JSONArray): List<Line> = List(json.length()) { i ->
        json.getJSONObject(i).let { Line(it.getLong("productId"), it.getString("name"), it.getDouble("price"), it.getInt("qty")) }
    }
    fun linesJson(lines: List<Line>) = JSONArray().apply { lines.forEach { put(JSONObject().put("productId",it.productId).put("name",it.name).put("price",it.price).put("qty",it.qty)) } }
    fun readSales(): MutableList<Sale> {
        val a = runCatching { JSONArray(prefs.getString("sales", "[]")) }.getOrDefault(JSONArray())
        return MutableList(a.length()) { i -> a.getJSONObject(i).let { Sale(it.getLong("id"),it.getString("client"),it.getString("date"),readLines(it.getJSONArray("lines")),it.getDouble("total")) } }
    }
    fun writeSales(list: List<Sale>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id",it.id).put("client",it.client).put("date",it.date).put("lines",linesJson(it.lines)).put("total",it.total)) }
        prefs.edit().putString("sales",a.toString()).apply()
    }
    fun readDrafts(): MutableList<Draft> {
        val a = runCatching { JSONArray(prefs.getString("drafts", "[]")) }.getOrDefault(JSONArray())
        return MutableList(a.length()) { i -> a.getJSONObject(i).let { Draft(it.getLong("id"),it.getString("client"),it.getString("date"),readLines(it.getJSONArray("lines")),it.getDouble("total")) } }
    }
    fun writeDrafts(list: List<Draft>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id",it.id).put("client",it.client).put("date",it.date).put("lines",linesJson(it.lines)).put("total",it.total)) }
        prefs.edit().putString("drafts",a.toString()).apply()
    }

    var products by remember { mutableStateOf(readProducts().toList()) }
    var sales by remember { mutableStateOf(readSales().toList()) }
    var drafts by remember { mutableStateOf(readDrafts().toList()) }
    var cart by remember { mutableStateOf(listOf<Line>()) }
    var client by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Inicio") }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var adminUnlocked by remember { mutableStateOf(false) }
    var showAdminPin by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var productName by remember { mutableStateOf("") }
    var productPrice by remember { mutableStateOf("") }
    var productDesc by remember { mutableStateOf("") }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var toast by remember { mutableStateOf("") }
    var allDates by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val txt = buildString {
                appendLine("AD-LO — VENTAS DEL DÍA")
                appendLine("Fecha: $dayStamp()")
                appendLine("=".repeat(32))
                sales.filter { it.date.startsWith(dayStamp()) }.forEach { s ->
                    appendLine("Cliente: ${s.client}")
                    appendLine("Fecha: ${s.date}")
                    s.lines.forEach { appendLine("${it.qty} x ${it.name} - ${money(it.total)}") }
                    appendLine("TOTAL: ${money(s.total)}")
                    appendLine("-".repeat(32))
                }
                appendLine("TOTAL DEL DÍA: ${money(sales.filter { it.date.startsWith(dayStamp()) }.sumOf { it.total })}")
            }
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(txt) } }
            toast = "Archivo TXT guardado"
        }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Green) else lightColorScheme(primary = Green)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(if (dark) Color(0xFF0F172A) else Color.White).padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("AD-LO", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Green)
                        Text("SISTEMA DE GESTIÓN", fontSize = 10.sp, color = Muted, letterSpacing = 2.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark",dark).apply() }) {
                            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Cambiar tema")
                        }
                        IconButton(onClick = { page = "Menú" }) { Icon(Icons.Default.Menu, "Menú") }
                    }
                }
                when (page) {
                    "Inicio" -> {
                        LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            item {
                                Card(Modifier.fillMaxWidth().clickable { page = "Catálogo" }, colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(24.dp)) {
                                    Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("ACCESO DIRECTO", color = Color.White.copy(alpha=.8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text("Catálogo General", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                                            Text("Crear ventas y registrar pedidos", color = Color.White)
                                        }
                                        Icon(Icons.Default.ShoppingBag, null, tint = Color.White, modifier = Modifier.size(40.dp))
                                    }
                                }
                            }
                            item { SummaryCard("Ventas de hoy", sales.filter { it.date.startsWith(dayStamp()) }.size.toString(), "Total: ${money(sales.filter { it.date.startsWith(dayStamp()) }.sumOf { it.total })}") }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Últimos borradores", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    TextButton(onClick = { page = "Borradores" }) { Text("Ver todos") }
                                }
                            }
                            if (drafts.isEmpty()) item { Text("No hay preventas guardadas.", color = Muted) }
                            items(drafts.takeLast(4).reversed()) { d ->
                                Card(Modifier.fillMaxWidth().clickable { cart = d.lines; client = d.client; drafts = drafts.filterNot { it.id == d.id }; writeDrafts(drafts); page = "Catálogo"; toast = "Borrador cargado" }) {
                                    Column(Modifier.padding(14.dp)) { Text(d.client.ifBlank { "Cliente sin nombre" }, fontWeight = FontWeight.Bold); Text("${d.lines.size} productos · ${money(d.total)}", color = Muted) }
                                }
                            }
                        }
                    }
                    "Catálogo" -> {
                        Column(Modifier.weight(1f).padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                TextButton(onClick = { page = "Inicio" }) { Icon(Icons.Default.ArrowBack, null); Text(" Volver") }
                                Button(onClick = { page = "Carrito" }) { Icon(Icons.Default.ShoppingCart, null); Text(" Carrito (${cart.sumOf { it.qty }})") }
                            }
                            OutlinedTextField(value = client, onValueChange = { client = it }, label = { Text("Nombre del cliente *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Buscar productos") }, leadingIcon = { Icon(Icons.Default.Search,null) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Spacer(Modifier.height(10.dp))
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                items(products.filter { it.name.contains(search, true) || it.desc.contains(search, true) }) { p ->
                                    Card(Modifier.fillMaxWidth().clickable {
                                        val old = cart.find { it.productId == p.id }
                                        cart = if (old == null) cart + Line(p.id,p.name,p.price,1) else cart.map { if (it.productId == p.id) it.copy(qty=it.qty+1) else it }
                                        toast = "${p.name} agregado"
                                    }) {
                                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) { Text(p.name,fontWeight=FontWeight.Bold); if (p.desc.isNotBlank()) Text(p.desc,color=Muted,fontSize=12.sp) }
                                            Text(money(p.price), color=Green,fontWeight=FontWeight.Bold)
                                            IconButton(onClick = { val old=cart.find { it.productId==p.id }; cart=if(old==null) cart+Line(p.id,p.name,p.price,1) else cart.map { if(it.productId==p.id) it.copy(qty=it.qty+1) else it } }) { Icon(Icons.Default.AddCircle, null, tint=Green) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    "Carrito" -> {
                        Column(Modifier.weight(1f).padding(16.dp)) {
                            Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={page="Catálogo"}) { Icon(Icons.Default.ArrowBack,null) }; Text("Carrito de Compras",fontSize=21.sp,fontWeight=FontWeight.Bold) }
                            LazyColumn(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                if (cart.isEmpty()) item { Text("El carrito está vacío.",color=Muted) }
                                items(cart) { line ->
                                    Card {
                                        Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) { Text(line.name,fontWeight=FontWeight.Bold); Text("${money(line.price)} c/u · ${money(line.total)}",color=Muted,fontSize=12.sp) }
                                            IconButton(onClick={cart=cart.mapNotNull { if(it.productId!=line.productId) it else if(it.qty>1) it.copy(qty=it.qty-1) else null }}) { Icon(Icons.Default.RemoveCircleOutline,null) }
                                            Text("${line.qty}",fontWeight=FontWeight.Bold)
                                            IconButton(onClick={cart=cart.map { if(it.productId==line.productId) it.copy(qty=it.qty+1) else it }}) { Icon(Icons.Default.AddCircle,null,tint=Green) }
                                        }
                                    }
                                }
                            }
                            HorizontalDivider()
                            Text("TOTAL: ${money(cart.sumOf { it.total })}",fontSize=24.sp,fontWeight=FontWeight.Black,color=Green)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(modifier=Modifier.weight(1f),onClick={
                                    if(cart.isNotEmpty()) { val d=Draft(System.currentTimeMillis(),client,stamp(),cart,cart.sumOf { it.total }); drafts=drafts+d; writeDrafts(drafts); cart=emptyList(); client=""; page="Inicio"; toast="Preventa guardada" }
                                    else toast="Agrega productos primero"
                                }) { Text("Guardar preventa") }
                                Button(modifier=Modifier.weight(1f),onClick={
                                    if(cart.isEmpty()) toast="Agrega productos primero"
                                    else if(client.isBlank()) toast="Escribe el nombre del cliente"
                                    else { sales=sales+Sale(System.currentTimeMillis(),client.trim(),stamp(),cart,cart.sumOf { it.total }); writeSales(sales); cart=emptyList(); client=""; page="Inicio"; toast="Venta registrada" }
                                }) { Text("Confirmar venta") }
                            }
                        }
                    }
                    "Borradores" -> {
                        Column(Modifier.weight(1f).padding(16.dp)) {
                            Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={page="Inicio"}) { Icon(Icons.Default.ArrowBack,null) }; Text("Pre-ventas / Borradores",fontSize=20.sp,fontWeight=FontWeight.Bold) }
                            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                if(drafts.isEmpty()) item { Text("No hay borradores guardados.",color=Muted) }
                                items(drafts.reversed()) { d ->
                                    Card {
                                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                            Text(d.client.ifBlank { "Cliente sin nombre" },fontWeight=FontWeight.Bold)
                                            Text("${d.date} · ${money(d.total)}",color=Muted,fontSize=12.sp)
                                            Row { TextButton(onClick={cart=d.lines;client=d.client;drafts=drafts.filterNot{it.id==d.id};writeDrafts(drafts);page="Carrito"}) { Text("Continuar") }; TextButton(onClick={drafts=drafts.filterNot{it.id==d.id};writeDrafts(drafts);toast="Borrador eliminado"}) { Text("Eliminar",color=Color.Red) } }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    "Movimientos" -> {
                        Column(Modifier.weight(1f).padding(16.dp)) {
                            Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={page="Menú"}) { Icon(Icons.Default.ArrowBack,null) }; Text("Movimientos de ventas",fontSize=20.sp,fontWeight=FontWeight.Bold) }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected=!allDates,onClick={allDates=false},label={Text("Hoy")})
                                FilterChip(selected=allDates,onClick={allDates=true},label={Text("Todas las fechas")})
                            }
                            val shown=sales.filter { allDates || it.date.startsWith(dayStamp()) }.reversed()
                            Text("Total: ${money(shown.sumOf { it.total })} · ${shown.size} ventas",fontWeight=FontWeight.Bold,color=Green,modifier=Modifier.padding(vertical=8.dp))
                            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                if(shown.isEmpty()) item { Text("No hay ventas en este filtro.",color=Muted) }
                                items(shown) { s ->
                                    Card { Column(Modifier.padding(14.dp)) { Text(s.client,fontWeight=FontWeight.Bold); Text(s.date,color=Muted,fontSize=12.sp); s.lines.forEach { Text("${it.qty} × ${it.name} — ${money(it.total)}",fontSize=13.sp) }; Text("TOTAL ${money(s.total)}",color=Green,fontWeight=FontWeight.Black) } }
                                }
                            }
                        }
                    }
                    "Administrador" -> {
                        Column(Modifier.weight(1f).padding(16.dp)) {
                            Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={page="Menú"}) { Icon(Icons.Default.ArrowBack,null) }; Text("Administrar productos",fontSize=20.sp,fontWeight=FontWeight.Bold) }
                            if (!adminUnlocked) {
                                Text("Introduce el PIN de administrador.")
                                OutlinedTextField(value=pin,onValueChange={pin=it},label={Text("PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
                                Button(onClick={ if(pin == prefs.getString("pin","123456")) { adminUnlocked=true; pin="" } else { toast="PIN incorrecto"; pin="" } }) { Text("Entrar") }
                            } else {
                                OutlinedTextField(value=productName,onValueChange={productName=it},label={Text("Nombre del producto")},modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(value=productPrice,onValueChange={productPrice=it},label={Text("Precio (L)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(value=productDesc,onValueChange={productDesc=it},label={Text("Descripción")},modifier=Modifier.fillMaxWidth())
                                Button(onClick={
                                    val n=productName.trim(); val p=productPrice.replace(",",".").toDoubleOrNull()
                                    if(n.isBlank()||p==null||p<0) toast="Revisa nombre y precio"
                                    else {
                                        val id=editingId ?: System.currentTimeMillis()
                                        val product=Product(id,n,p,productDesc.trim())
                                        products=if(editingId==null) products+product else products.map { if(it.id==id) product else it }
                                        writeProducts(products); productName="";productPrice="";productDesc="";editingId=null;toast="Producto guardado"
                                    }
                                },modifier=Modifier.fillMaxWidth()) { Text(if(editingId==null) "Agregar producto" else "Guardar cambios") }
                                if(editingId!=null) TextButton(onClick={editingId=null;productName="";productPrice="";productDesc=""}) { Text("Cancelar edición") }
                                Spacer(Modifier.height(12.dp))
                                LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                                    items(products) { p ->
                                        Card { Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) { Text(p.name,fontWeight=FontWeight.Bold); Text("${money(p.price)} · ${p.desc}",color=Muted,fontSize=12.sp) }
                                            IconButton(onClick={editingId=p.id;productName=p.name;productPrice=p.price.toString();productDesc=p.desc}) { Icon(Icons.Default.Edit,null) }
                                            IconButton(onClick={products=products.filterNot{it.id==p.id};writeProducts(products);toast="Producto eliminado"}) { Icon(Icons.Default.Delete,null,tint=Color.Red) }
                                        } }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Column(Modifier.weight(1f).padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                            Text("Menú principal",fontSize=22.sp,fontWeight=FontWeight.Bold)
                            MenuRow("Catálogo General","Crear ventas y pedidos") { page="Catálogo" }
                            MenuRow("Pre-ventas / Borradores","Continuar pedidos guardados") { page="Borradores" }
                            MenuRow("Movimientos del Día","Consultar ventas registradas") { page="Movimientos" }
                            MenuRow("Perfil de Administrador","Gestionar productos") { page="Administrador" }
                            MenuRow("Descargar ventas del día (.txt)","Guardar un informe en el teléfono") { exportLauncher.launch("ADLO-ventas-${dayStamp()}.txt") }
                            MenuRow(if(dark) "Activar modo claro" else "Activar modo oscuro","Cambiar apariencia") { dark=!dark;prefs.edit().putBoolean("dark",dark).apply() }
                            Text("AD-LO · versión nativa 0.1",color=Muted,fontSize=12.sp)
                        }
                    }
                }
                if (toast.isNotBlank()) {
                    Snackbar(modifier=Modifier.padding(12.dp), action={ TextButton(onClick={toast=""}) { Text("Cerrar") } }) { Text(toast) }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, subtitle: String) {
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(18.dp)) {
            Text(title,color=Muted,fontSize=12.sp)
            Text(value,fontSize=30.sp,fontWeight=FontWeight.Black)
            Text(subtitle,color=Green,fontWeight=FontWeight.SemiBold)
        }
    }
}
@Composable
private fun MenuRow(title: String, desc: String, action: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick=action)) {
        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.Bold); Text(desc,color=Muted,fontSize=12.sp) }
            Icon(Icons.Default.ChevronRight,null,tint=Green)
        }
    }
}

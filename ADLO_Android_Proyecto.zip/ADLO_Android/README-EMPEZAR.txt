AD-LO Android — proyecto inicial nativo

Qué contiene esta primera base:
- Aplicación Android nativa en Kotlin + Jetpack Compose.
- Catálogo con búsqueda, carrito y registro de ventas.
- Borradores/preventas.
- Movimientos de ventas (hoy y todas las fechas).
- Administración básica de productos protegida por PIN inicial 123456.
- Datos guardados localmente en el teléfono.
- Exportación de ventas del día como TXT mediante el selector nativo de Android.
- Flujo de compilación APK en GitHub Actions para trabajar desde el teléfono.

Cómo obtener el APK usando solo el teléfono:
1. Crea una cuenta en GitHub si no tienes.
2. Crea un repositorio nuevo llamado AD-LO-Android.
3. Sube el contenido de esta carpeta al repositorio (incluida la carpeta .github).
4. En el repositorio abre Actions y ejecuta “Build AD-LO APK” (o espera a que termine).
5. Abre la ejecución terminada y descarga el artefacto “AD-LO-debug-apk”.
6. Descomprime el ZIP descargado e instala app-debug.apk. Android puede pedir permiso para instalar desde el navegador/archivos.

Nota:
- Esta es la primera versión funcional de base, no una compilación APK ya probada en tu dispositivo.
- El código fuente se puede editar y volver a compilar desde GitHub.
- PIN de administrador inicial: 123456. Cámbialo dentro de la app después de verificar la primera compilación.
- La aplicación comienza con productos de ejemplo; no importa ni conserva los datos guardados en el HTML.
